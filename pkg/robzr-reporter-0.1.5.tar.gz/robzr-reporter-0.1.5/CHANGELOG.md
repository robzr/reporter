### v0.1.15 - 2016-06-25
  * Refactor, updated documentation, changed license

### v0.1.0 - 2016-10-20
  * Initial release
